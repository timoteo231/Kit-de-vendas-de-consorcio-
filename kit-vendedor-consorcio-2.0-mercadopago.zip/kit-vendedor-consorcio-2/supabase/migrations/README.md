O schema atual foi aplicado diretamente ao projeto Supabase remoto `jlvjxepgpkinddypsbre` e inclui as tabelas `profiles`, `courses`, `lessons`, `materials`, `access_grants`, `orders` e `subscriptions`, políticas RLS, função de verificação de administrador e bucket privado `kit-materiais`.

A antiga migração inicial do starter foi removida porque não correspondia ao schema remoto que está em uso. Antes de gerar novas migrações versionadas, faça um `supabase db pull` do projeto remoto e revise o diff. Não reaplique uma migração inicial sobre o banco existente.


Alterações remotas adicionadas para o checkout Mercado Pago:

- `courses.price_cents` e `courses.currency` para precificação em BRL.
- Índice único `access_grants_external_reference_key` para garantir idempotência das liberações automáticas.
- Índice redundante `orders_user_created_idx` removido; o índice equivalente `orders_user_created_at_idx` foi mantido.

Essas alterações já foram aplicadas ao projeto remoto associado a este kit. Antes de sincronizar um ambiente local novo, faça `supabase db pull` e revise o histórico do projeto; não reaplique o schema inicial sobre o banco existente.
