# Registro de decisões

- Pagamento: ainda não decidido; arquitetura com adaptador para permitir Kiwify/Hotmart.
- Modelo: compra única + assinatura.
- Vídeos: serviço externo; fornecedor pendente.
- Hospedagem: Vercel, inicialmente em subdomínio vercel.app.
- Visual: preservar verde profundo, dourado, branco e tipografia Instrument Serif/Manrope.
- Idioma: pt-BR.
- Fuso padrão de negócio: America/Belem (confirmar na configuração do projeto).
