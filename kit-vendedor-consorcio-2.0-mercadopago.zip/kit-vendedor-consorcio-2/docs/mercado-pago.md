# Integração Mercado Pago — Checkout Pro

## O que o código faz

- Exige sessão autenticada para iniciar compra.
- Busca o curso publicado e lê o preço diretamente do banco; o navegador não informa o valor.
- Cria o pedido local em `public.orders` e uma order Checkout Pro pela Orders API no Mercado Pago.
- Redireciona para o `checkout_url` retornado pelo endpoint Orders API; o ambiente é determinado pelo Access Token usado.
- Recebe notificações do evento `order`, valida `x-signature` (HMAC SHA-256, `x-request-id`, `data.id` e tolerância temporal), consulta a order diretamente na API do Mercado Pago e confere valor/moeda com o pedido local.
- Só libera o curso quando a order estiver `processed` e o valor integral tiver sido pago; a concessão é idempotente usando `access_grants.external_reference`.
- Reembolsos e chargebacks precisam ser tratados pelo processo de suporte/administrador; não são automatizados nesta primeira versão.
- O retorno do navegador é apenas informativo e nunca concede acesso.

## Variáveis de ambiente

| Variável | Onde obter | Exposição |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Project URL | Pública |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Supabase → Publishable key | Pública |
| `SUPABASE_SECRET_KEY` | Supabase → Settings → API Keys → Secret key (`sb_secret_...`) | Somente servidor |
| `MP_ACCESS_TOKEN` | Mercado Pago Developers → aplicação → Credenciais de teste/produção | Somente servidor |
| `MP_WEBHOOK_SECRET` | Mercado Pago Developers → aplicação → Webhooks → assinatura secreta | Somente servidor |
| `APP_URL` | URL HTTPS pública do site, sem barra final | Servidor |
| `MP_ENVIRONMENT` | `sandbox` ou `production` | Servidor |

Não use prefixo `NEXT_PUBLIC_` nas variáveis secretas. Não faça commit de `.env.local`.

## Homologação (sandbox)

1. Crie uma aplicação em Mercado Pago Developers e selecione Checkout Pro.
2. Copie as credenciais de teste e configure `MP_ACCESS_TOKEN=TEST-...`.
3. Configure `MP_ENVIRONMENT=sandbox`. O código exige token `TEST-` nesse ambiente e bloqueia token de produção.
4. Na Vercel, configure `APP_URL` com a URL HTTPS do deployment.
5. Configure `SUPABASE_SECRET_KEY` com a chave secreta do Supabase. Ela é usada apenas nos Route Handlers no servidor para gravar pedidos e concessões, ignorando RLS de forma controlada.
6. No painel do Mercado Pago → Webhooks, cadastre `https://SEU-DOMINIO/api/webhooks/mercadopago`, habilite o evento **Order (Mercado Pago)**, salve e copie a assinatura secreta para `MP_WEBHOOK_SECRET`.
7. Faça redeploy depois de inserir/alterar as variáveis.
8. No painel de administração `/admin/cursos`, defina preço maior que zero e publique um curso.
9. Crie uma conta de aluno, entre e abra `/cursos`. Inicie uma compra de teste.
10. Para validar a notificação, use a ferramenta de simulação de Webhooks no painel Mercado Pago com o ID da order de teste. A documentação informa que pagamentos criados com credenciais de teste não necessariamente enviam notificações automáticas; use a simulação para testar a entrega.
11. Confirme em `/admin` que o pedido aparece como `paid` e que o aluno vê o curso em `/dashboard`.

## Produção

Depois de homologar, troque o Access Token pelas credenciais de produção, configure `MP_ENVIRONMENT=production`, configure a URL/assinatura de webhook do ambiente de produção e faça redeploy. Faça uma compra real de baixo valor antes de divulgar.

## Limitações atuais

- Checkout Pro de pagamento único; não implementa recorrência/assinaturas.
- Os meios efetivamente exibidos (Pix/cartão e parcelamento) dependem da configuração, elegibilidade e análise da conta Mercado Pago.
- O webhook processa o evento `order`; outros eventos não concedem acesso.
- Reembolsos e chargebacks devem ser acompanhados no painel do Mercado Pago e a concessão de acesso deve ser revogada pelo administrador. A automação desses eventos fica para uma próxima etapa.
- Build e testes de integração precisam ser executados depois de `npm install` em ambiente com acesso ao registry e credenciais de sandbox.


## API utilizada

Esta implementação usa a **Orders API** (`POST /v1/orders` e `GET /v1/orders/{id}`), recomendada atualmente pelo Mercado Pago para novas integrações Checkout Pro. A antiga Preferences API permanece suportada, mas é classificada como fluxo legado.
