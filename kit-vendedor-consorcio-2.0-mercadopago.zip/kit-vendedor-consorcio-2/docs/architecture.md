# Arquitetura funcional — Kit do Vendedor 2.0

> Banco de dados: usar exclusivamente o Supabase Database, que é PostgreSQL gerenciado pelo Supabase. Não provisionar nem manter uma instância PostgreSQL separada.

## Decisões
- Next.js App Router + TypeScript.
- Supabase Database (PostgreSQL gerenciado), Supabase Auth e Supabase Storage.
- Vercel para hospedagem.
- Vídeos em provedor externo, selecionado posteriormente.
- Checkout independente do provedor (Kiwify/Hotmart ainda não decidido).
- Compra única e assinatura como modalidades de acesso.

## Modelo de acesso
`products` representa o produto comercial. `plans` representa ofertas/condições de cobrança. `orders` representa a compra. `subscriptions` representa a recorrência. `access_grants` representa o direito efetivo de acesso.

Compra única: `access_grants.ends_at = null`, com status ativo até eventual revogação por reembolso/chargeback conforme política.
Assinatura: grant com `ends_at` atualizado a cada período pago. Cancelamento ao fim do período mantém o acesso até `current_period_end`; inadimplência segue regra comercial definida antes da integração.

## Segurança
- Autenticação validada no servidor com `getClaims()`.
- RLS em todas as tabelas do schema exposto.
- `user_metadata` nunca concede função administrativa.
- Chave secreta nunca vai ao browser.
- Operações de pagamento e administração somente no servidor.
- Webhooks idempotentes por provedor + ID do evento.
- Conteúdo de aulas deve ser filtrado por matrícula/grant válido.

## Vídeo externo
Guardar identificador do ativo e provedor. O servidor valida o acesso e fornece o player/URL permitida. Não aceitar HTML de iframe fornecido por usuários.

## PWA
Manifest inicial incluído. Service worker, estratégia offline e notificações ficam para fase posterior. Não armazenar conteúdo pago sensível em cache público.

## Pendências bloqueadoras de produção
1. Escolher provedor de pagamento e implementar webhooks oficiais.
2. Definir preço, periodicidade, carência e regras de inadimplência.
3. Escolher provedor de vídeo e política de incorporação.
4. Definir conteúdo exato de cada produto/plano.
5. Implementar políticas RLS de leitura de conteúdo e endpoints admin.
6. Configurar e testar e-mail transacional.
7. Realizar testes de segurança, acessibilidade e carga.
