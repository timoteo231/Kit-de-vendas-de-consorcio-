import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { BuyCourseButton } from '@/components/buy-course-button';

function money(cents: number) { return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(cents / 100); }

export default async function CoursesPage() {
  const supabase = await createClient();
  const { data: courses } = await supabase.from('courses').select('id,title,slug,description,price_cents,currency').eq('status', 'published').order('sort_order').order('created_at', { ascending: false });
  return <main className="portal-shell"><header className="portal-top"><Link href="/" className="brand">KIT DO <span className="brand-mark">VENDEDOR</span></Link><Link className="btn ghost" href="/login">Entrar</Link></header><section className="portal-content"><span className="eyebrow gold">Cursos disponíveis</span><h1>Escolha seu próximo passo.</h1><p className="muted">Acesse o checkout seguro do Mercado Pago para comprar seu curso.</p><div className="portal-grid">{(courses || []).map(course=><article className="card" key={course.id}><h2>{course.title}</h2><p>{course.description}</p><div className="price" style={{fontSize:42,margin:'20px 0'}}>{money(course.price_cents)}</div>{course.price_cents > 0 ? <BuyCourseButton courseId={course.id}/> : <p className="notice">Preço em configuração. Em breve disponível.</p>}</article>)}</div>{!courses?.length&&<article className="card"><h2>Novos cursos em breve</h2><p>Estamos preparando os primeiros conteúdos.</p></article>}</section></main>;
}
