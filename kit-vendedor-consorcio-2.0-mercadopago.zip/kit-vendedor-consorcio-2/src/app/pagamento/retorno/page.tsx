import Link from 'next/link';

type Props = { searchParams: Promise<{ status?: string }> };
export default async function PaymentReturn({ searchParams }: Props) {
  const { status } = await searchParams;
  const message = status === 'success'
    ? 'Recebemos seu retorno do Mercado Pago. A confirmação final será feita pelo servidor; seu curso aparecerá na área do aluno assim que o pagamento for aprovado.'
    : status === 'pending'
      ? 'Seu pagamento está pendente. Assim que o Mercado Pago confirmar a aprovação, o acesso será liberado automaticamente.'
      : 'O pagamento não foi concluído. Você pode voltar aos cursos e tentar novamente.';
  return <main className="auth-shell"><section className="auth-card"><span className="eyebrow gold">Status da compra</span><h1>Obrigado!</h1><p className="muted">{message}</p><Link className="btn" href="/dashboard">Ir para minha área</Link><Link className="back-link" href="/cursos">Voltar aos cursos</Link></section></main>;
}
