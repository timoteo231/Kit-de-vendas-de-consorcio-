import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Kit do Vendedor de Consórcio",
    template: "%s | Kit do Vendedor",
  },
  description:
    "Capacitação, scripts e ferramentas profissionais para vendedores de consórcio.",
  applicationName: "Kit do Vendedor",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "Kit do Vendedor" },
};

export const viewport: Viewport = {
  themeColor: "#103D35",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
