import { randomUUID } from 'node:crypto';
import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  try {
    const origin = request.headers.get('origin');
    if (origin && origin !== new URL(request.url).origin) return NextResponse.json({ error: 'Origem da solicitação inválida.' }, { status: 403 });
    const supabase = await createClient();
    const { data: claimsData } = await supabase.auth.getClaims();
    const userId = claimsData?.claims?.sub;
    const email = typeof claimsData?.claims?.email === 'string' ? claimsData.claims.email : '';
    if (!userId || !email) return NextResponse.json({ error: 'Entre na sua conta antes de comprar.' }, { status: 401 });

    const body = await request.json().catch(() => null);
    const courseId = typeof body?.courseId === 'string' ? body.courseId : '';
    if (!courseId) return NextResponse.json({ error: 'Curso inválido.' }, { status: 400 });

    const { data: course, error: courseError } = await supabase
      .from('courses').select('id,title,description,status,price_cents,currency').eq('id', courseId).eq('status', 'published').maybeSingle();
    if (courseError || !course) return NextResponse.json({ error: 'Curso não encontrado ou indisponível.' }, { status: 404 });
    if (!Number.isSafeInteger(course.price_cents) || course.price_cents <= 0 || course.currency !== 'BRL') {
      return NextResponse.json({ error: 'Este curso ainda não possui preço configurado para compra.' }, { status: 400 });
    }

    const now = new Date().toISOString();
    const access = await supabase.from('access_grants').select('id').eq('user_id', userId).eq('course_id', course.id).eq('status', 'active').lte('starts_at', now).or(`ends_at.is.null,ends_at.gt.${now}`).limit(1).maybeSingle();
    if (access.data) return NextResponse.json({ error: 'Você já possui acesso a este curso.', redirect: '/dashboard' }, { status: 409 });

    const token = process.env.MP_ACCESS_TOKEN;
    const appUrl = (process.env.APP_URL || process.env.NEXT_PUBLIC_APP_URL || '').replace(/\/$/, '');
    const environment = process.env.MP_ENVIRONMENT;
    const tokenMatchesEnvironment = environment === 'sandbox' ? token?.startsWith('TEST-') : environment === 'production' ? token?.startsWith('APP_USR-') : false;
    if (!token || !tokenMatchesEnvironment || !process.env.MP_WEBHOOK_SECRET || !process.env.SUPABASE_SECRET_KEY || !appUrl || !appUrl.startsWith('https://')) {
      return NextResponse.json({ error: 'O checkout ainda não está configurado. O administrador deve configurar SUPABASE_SECRET_KEY, MP_ACCESS_TOKEN, MP_WEBHOOK_SECRET, APP_URL e MP_ENVIRONMENT.' }, { status: 503 });
    }

    const admin = createAdminClient();
    const localReference = `creating_${randomUUID()}`;
    const { data: order, error: orderError } = await admin.from('orders').insert({
      user_id: userId,
      provider: 'mercadopago',
      external_order_id: localReference,
      status: 'pending',
      amount_cents: course.price_cents,
      currency: 'BRL',
      metadata: { course_id: course.id, course_title: course.title },
    }).select('id').single();
    if (orderError || !order) throw new Error('Não foi possível registrar o pedido.');

    const mpOrderPayload = {
      type: 'online',
      processing_mode: 'manual',
      capture_mode: 'automatic_async',
      total_amount: (course.price_cents / 100).toFixed(2),
      external_reference: order.id,
      payer: { email },
      items: [{ title: course.title.slice(0, 250), description: (course.description || 'Acesso digital ao curso').slice(0, 250), quantity: 1, unit_price: (course.price_cents / 100).toFixed(2) }],
      config: { online: { success_url: `${appUrl}/pagamento/retorno?status=success`, pending_url: `${appUrl}/pagamento/retorno?status=pending`, failure_url: `${appUrl}/pagamento/retorno?status=failure`, auto_return: 'approved' } },
    };

    const mpResponse = await fetch('https://api.mercadopago.com/v1/orders', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': order.id },
      body: JSON.stringify(mpOrderPayload),
      cache: 'no-store',
    });
    const mpOrder = await mpResponse.json().catch(() => ({}));
    if (!mpResponse.ok || !mpOrder.id || !mpOrder.checkout_url) {
      await admin.from('orders').delete().eq('id', order.id);
      console.error('Mercado Pago order error', mpResponse.status, mpOrder);
      return NextResponse.json({ error: 'O Mercado Pago não conseguiu criar o checkout. Confira as credenciais e tente novamente.' }, { status: 502 });
    }

    const { error: updateError } = await admin.from('orders').update({
      external_order_id: String(mpOrder.id),
      updated_at: new Date().toISOString(),
    }).eq('id', order.id);
    if (updateError) throw new Error('Checkout criado, mas não foi possível salvar a referência do pedido.');

    return NextResponse.json({ checkoutUrl: mpOrder.checkout_url });
  } catch (error) {
    console.error('Checkout error', error);
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Erro ao iniciar pagamento.' }, { status: 500 });
  }
}
