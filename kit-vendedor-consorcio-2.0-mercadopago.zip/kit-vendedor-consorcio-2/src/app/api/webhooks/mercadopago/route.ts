import { createHmac, timingSafeEqual } from 'node:crypto';
import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';

export const runtime = 'nodejs';

function validSignature(request: Request, dataId: string, secret: string) {
  const signature = request.headers.get('x-signature') || '';
  const requestId = request.headers.get('x-request-id') || '';
  const parts = Object.fromEntries(signature.split(',').map((part) => {
    const [key, ...value] = part.trim().split('=');
    return [key, value.join('=')];
  }));
  if (!parts.ts || !parts.v1 || !requestId || !dataId) return false;
  const timestamp = Number(parts.ts);
  if (!Number.isFinite(timestamp) || Math.abs(Date.now() - timestamp) > 5 * 60 * 1000) return false;
  const manifest = `id:${dataId.toLowerCase()};request-id:${requestId};ts:${parts.ts};`;
  const expected = createHmac('sha256', secret).update(manifest).digest('hex');
  const receivedBuffer = Buffer.from(parts.v1, 'hex');
  const expectedBuffer = Buffer.from(expected, 'hex');
  return receivedBuffer.length === expectedBuffer.length && timingSafeEqual(receivedBuffer, expectedBuffer);
}

export async function POST(request: Request) {
  const url = new URL(request.url);
  const body = await request.clone().json().catch(() => ({}));
  const type = url.searchParams.get('type') || url.searchParams.get('topic') || body.type;
  if (type !== 'order') return NextResponse.json({ received: true, ignored: true });

  const dataId = url.searchParams.get('data.id') || url.searchParams.get('id') || String(body?.data?.id || '');
  const secret = process.env.MP_WEBHOOK_SECRET;
  if (!secret || !validSignature(request, dataId, secret)) {
    return NextResponse.json({ error: 'Assinatura inválida.' }, { status: 401 });
  }

  const token = process.env.MP_ACCESS_TOKEN;
  if (!token) return NextResponse.json({ error: 'Gateway não configurado.' }, { status: 503 });

  try {
    // The webhook is only a signal. Always fetch the canonical order from Mercado Pago.
    const orderResponse = await fetch(`https://api.mercadopago.com/v1/orders/${encodeURIComponent(dataId)}`, {
      headers: { Authorization: `Bearer ${token}` }, cache: 'no-store',
    });
    if (!orderResponse.ok) return NextResponse.json({ error: 'Não foi possível consultar a order.' }, { status: 502 });
    const mpOrder = await orderResponse.json();
    const orderId = String(mpOrder.external_reference || '');
    if (!orderId) return NextResponse.json({ error: 'Pedido não identificado.' }, { status: 200 });

    const admin = createAdminClient();
    const { data: order, error: orderError } = await admin.from('orders').select('id,user_id,amount_cents,currency,status,metadata,paid_at').eq('id', orderId).eq('provider', 'mercadopago').maybeSingle();
    if (orderError || !order) return NextResponse.json({ error: 'Pedido não encontrado.' }, { status: 404 });

    const mpStatus = String(mpOrder.status || 'created');
    const receivedCents = Math.round(Number(mpOrder.total_paid_amount || 0) * 100);
    if (mpOrder.currency && mpOrder.currency !== order.currency) {
      console.error('Payment currency mismatch', { orderId, orderResourceId: dataId });
      return NextResponse.json({ error: 'Moeda divergente.' }, { status: 409 });
    }
    const statusMap: Record<string, string> = {
      processed: 'paid', cancelled: 'cancelled', failed: 'rejected', action_required: 'pending',
      created: 'pending', processing: 'pending', expired: 'cancelled',
    };
    const nextStatus = statusMap[mpStatus] || 'pending';
    if (nextStatus === 'paid' && receivedCents !== Number(order.amount_cents)) {
      console.error('Payment amount mismatch', { orderId, orderResourceId: dataId, receivedCents });
      return NextResponse.json({ error: 'Valor pago divergente.' }, { status: 409 });
    }
    const alreadyPaid = order.status === 'paid';
    const finalStatus = alreadyPaid ? 'paid' : nextStatus;

    const orderUpdate: Record<string, unknown> = {
      status: finalStatus,
      metadata: { ...(order.metadata || {}), mercadopago_order_id: String(dataId), mercadopago_status: mpStatus, total_paid_amount: mpOrder.total_paid_amount || '0.00', transactions: mpOrder.transactions || null },
      updated_at: new Date().toISOString(),
    };
    if (finalStatus === 'paid' && !order.paid_at) orderUpdate.paid_at = new Date().toISOString();
    const { error: updateError } = await admin.from('orders').update(orderUpdate).eq('id', order.id);
    if (updateError) throw updateError;

    const courseId = String(order.metadata?.course_id || '');
    if (!courseId) throw new Error('Pedido sem curso associado.');
    if (finalStatus === 'paid') {
      const { error: grantError } = await admin.from('access_grants').upsert({
        user_id: order.user_id, course_id: courseId, source: 'mercadopago', status: 'active',
        starts_at: new Date().toISOString(), ends_at: null, external_reference: order.id,
      }, { onConflict: 'external_reference' });
      if (grantError) throw grantError;
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error('Mercado Pago webhook processing error', error);
    return NextResponse.json({ error: 'Falha ao processar notificação.' }, { status: 500 });
  }
}
