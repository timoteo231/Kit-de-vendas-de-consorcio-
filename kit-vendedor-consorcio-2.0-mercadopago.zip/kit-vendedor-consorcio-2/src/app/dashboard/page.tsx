import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: claimsData } = await supabase.auth.getClaims();
  const userId = claimsData?.claims?.sub;
  if (!userId) redirect('/login');
  const [{ data: profile }, { data: grants }] = await Promise.all([
    supabase.from('profiles').select('full_name, role').eq('id', userId).maybeSingle(),
    supabase.from('access_grants').select('course_id, status, starts_at, ends_at').eq('user_id', userId).eq('status', 'active'),
  ]);
  const ids = (grants ?? []).filter(g => new Date(g.starts_at) <= new Date() && (!g.ends_at || new Date(g.ends_at) > new Date())).map(g => g.course_id);
  const { data: courses } = ids.length ? await supabase.from('courses').select('id,title,slug,description,cover_image_url').in('id', ids).eq('status','published') : { data: [] };
  return <main className="portal-shell"><header className="portal-top"><Link href="/" className="brand">KIT DO <span className="brand-mark">VENDEDOR</span></Link><form action="/auth/signout" method="post"><button className="btn ghost">Sair</button></form></header><section className="portal-content"><span className="eyebrow">Área do aluno</span><h1>Olá, {profile?.full_name || claimsData?.claims?.email || 'aluno'}.</h1><p className="muted">Aqui ficam os cursos liberados para sua conta.</p><div className="portal-grid">{courses?.length ? courses.map(course=><article className="card" key={course.id}><span className="eyebrow gold">Seu conteúdo</span><h2>{course.title}</h2><p>{course.description || 'Conteúdo disponível na sua área de aluno.'}</p><Link className="btn" href={`/aluno/cursos/${course.slug}`}>Acessar curso</Link></article>) : <article className="card"><h2>Nenhum curso liberado ainda</h2><p>Quando um pagamento for aprovado ou um acesso for concedido, o conteúdo aparecerá aqui.</p><Link className="btn" href="/cursos">Ver cursos disponíveis</Link></article>}</div></section></main>;
}
