import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function StudentDashboard() {
  const supabase = await createClient();
  const { data: { claims }, error } = await supabase.auth.getClaims();
  if (error || !claims?.sub) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name")
    .eq("id", claims.sub)
    .maybeSingle();

  return (
    <main className="dashboard">
      <aside className="sidebar">
        <div className="brand">KIT DO <span className="brand-mark">VENDEDOR</span></div>
        <p style={{color:"#cbd9d3", fontSize:13}}>ÁREA DO ALUNO</p>
        <Link href="/aluno">Visão geral</Link>
        <Link href="/aluno/cursos">Meus cursos</Link>
        <Link href="/aluno/scripts">Scripts</Link>
        <Link href="/aluno/artes">Artes e legendas</Link>
        <Link href="/aluno/leads">Meus leads</Link>
        <Link href="/">Voltar ao site</Link>
      </aside>
      <section className="dash-main">
        <span className="eyebrow">Seu espaço de aprendizagem</span>
        <h1 style={{fontSize:52}}>Olá{profile?.full_name ? `, ${profile.full_name}` : ""}.</h1>
        <p className="muted">Bem-vindo à sua área de aluno. Os módulos serão liberados conforme as permissões da sua matrícula.</p>
        <div className="dash-grid">
          <article className="card"><h3>Meus cursos</h3><p>Continue de onde parou.</p></article>
          <article className="card"><h3>Biblioteca</h3><p>Consulte scripts e materiais.</p></article>
          <article className="card"><h3>Meus leads</h3><p>Organize seus contatos.</p></article>
        </div>
        <p className="notice" style={{marginTop:24}}>Ambiente inicial: os módulos de conteúdo e controle de matrícula serão conectados nas próximas etapas.</p>
      </section>
    </main>
  );
}
