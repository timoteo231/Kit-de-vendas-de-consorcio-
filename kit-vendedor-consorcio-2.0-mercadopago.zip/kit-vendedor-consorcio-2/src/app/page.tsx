import Link from "next/link";
import { ObjectionDemo } from "@/components/objection-demo";

const features = [
  ["01", "Academia do vendedor", "Aulas objetivas, exercícios e acompanhamento do seu progresso."],
  ["02", "Biblioteca de scripts", "Abordagens, retomadas e respostas para conversas reais."],
  ["03", "Materiais de divulgação", "Artes editáveis, legendas e conteúdos organizados."],
  ["04", "Gestão de leads", "Organize contatos, etapas e próximos acompanhamentos."],
  ["05", "Ferramentas comerciais", "Recursos práticos para preparar conversas e melhorar sua rotina."],
  ["06", "Atualizações", "Novos materiais e conteúdos conforme o produto evoluir."],
];

export default function HomePage() {
  return (
    <main>
      <header className="wrap topbar">
        <div className="brand">KIT DO <span className="brand-mark">VENDEDOR</span></div>
        <div className="nav-actions">
          <Link className="btn ghost" href="/login">Entrar</Link>
          <Link className="btn" href="/cursos">Ver cursos</Link>
        </div>
      </header>

      <section className="hero">
        <div className="wrap hero-grid">
          <div>
            <div className="rule" />
            <span className="eyebrow">Capacitação • Estratégia • Ferramentas</span>
            <h1>Venda consórcio com clareza e confiança.</h1>
            <p className="lead">
              Aprenda a conduzir conversas, responder dúvidas e organizar sua rotina comercial
              com aulas, scripts e materiais profissionais.
            </p>
            <div className="hero-actions">
              <Link className="btn" href="/cursos">Ver cursos e valores</Link>
              <a className="btn ghost" href="#demonstracao">Ver demonstração</a>
            </div>
          </div>
          <div className="preview-card">
            <span className="eyebrow gold">Seu ambiente de vendas</span>
            <h2>Conhecimento que acompanha sua rotina.</h2>
            <p>Um só lugar para estudar, preparar abordagens e organizar seus contatos.</p>
            <div className="preview-stat">
              <div className="stat-tile"><b>05</b><span>Aulas iniciais</span></div>
              <div className="stat-tile"><b>30</b><span>Scripts comerciais</span></div>
              <div className="stat-tile"><b>20</b><span>Artes editáveis</span></div>
              <div className="stat-tile"><b>30</b><span>Legendas</span></div>
            </div>
          </div>
        </div>
      </section>

      <section className="wrap">
        <div className="metrics">
          <div className="metric"><b>5</b><span>aulas iniciais</span></div>
          <div className="metric"><b>30</b><span>scripts de vendas</span></div>
          <div className="metric"><b>20</b><span>artes editáveis</span></div>
          <div className="metric"><b>30</b><span>legendas prontas</span></div>
        </div>
      </section>

      <section className="section wrap" id="demonstracao">
        <div className="section-head">
          <span className="eyebrow">Demonstração interativa</span>
          <h2>Respostas melhores começam com uma boa conversa.</h2>
          <p className="muted">Treine abordagens sem prometer contemplação, resultados ou condições que dependem do contrato.</p>
        </div>
        <ObjectionDemo />
      </section>

      <section className="section wrap">
        <div className="section-head">
          <span className="eyebrow">O que você encontra</span>
          <h2>Uma estrutura para aprender e trabalhar.</h2>
        </div>
        <div className="cards">
          {features.map(([number, title, description]) => (
            <article className="card" key={number}>
              <div className="card-icon">{number}</div>
              <h3>{title}</h3>
              <p>{description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section wrap" id="planos">
        <div className="offer">
          <span className="eyebrow">Acesso à plataforma</span>
          <h2>Escolha a forma de acesso ideal.</h2>
          <p>Escolha um curso, confira o valor e finalize sua compra com segurança pelo Mercado Pago.</p>
          <ul className="offer-list">
            <li>Compra única com acesso aos conteúdos adquiridos</li>
            <li>Pagamento via Pix ou cartão conforme opções disponíveis no checkout</li>
            <li>Área de aluno e materiais organizados</li>
          </ul>
          <Link className="btn" href="/cursos">Ver cursos disponíveis</Link>
        </div>
      </section>

      <footer className="footer">
        <div className="wrap">
          <p><strong>Kit do Vendedor de Consórcio</strong> · Material educacional.</p>
          <p>Consórcio é regido por contrato e regras do grupo. A contemplação não possui data garantida. Consulte a administradora e os documentos aplicáveis.</p>
          <p>Políticas e informações institucionais serão publicadas antes da abertura das vendas.</p>
        </div>
      </footer>
    </main>
  );
}
