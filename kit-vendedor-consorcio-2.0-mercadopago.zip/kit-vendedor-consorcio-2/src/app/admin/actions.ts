'use server';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { randomUUID } from 'node:crypto';
import { createClient } from '@/lib/supabase/server';

async function adminClient() {
  const supabase = await createClient();
  const { data } = await supabase.auth.getClaims();
  const id = data?.claims?.sub;
  if (!id) redirect('/login');
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', id).maybeSingle();
  if (profile?.role !== 'admin') redirect('/dashboard');
  return supabase;
}

export async function createCourse(formData: FormData) {
  const supabase = await adminClient();
  const title = String(formData.get('title') || '').trim();
  const slug = String(formData.get('slug') || '').trim().toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-|-$/g, '');
  const price = Number(String(formData.get('price') || '0').replace(',', '.'));
  if (!title || !slug || !Number.isFinite(price) || price < 0 || price > 1000000) throw new Error('Informe título, identificador e preço válido.');
  const { error } = await supabase.from('courses').insert({ title, slug, description: String(formData.get('description') || '').trim(), price_cents: Math.round(price * 100), currency: 'BRL', status: 'draft' });
  if (error) throw new Error(error.message);
  revalidatePath('/admin'); revalidatePath('/admin/cursos'); redirect('/admin/cursos');
}

export async function setCoursePrice(formData: FormData) {
  const supabase = await adminClient();
  const id = String(formData.get('id') || '');
  const price = Number(String(formData.get('price') || '').replace(',', '.'));
  if (!id || !Number.isFinite(price) || price < 0 || price > 1000000) throw new Error('Informe um preço válido.');
  const { error } = await supabase.from('courses').update({ price_cents: Math.round(price * 100), currency: 'BRL', updated_at: new Date().toISOString() }).eq('id', id);
  if (error) throw new Error(error.message);
  revalidatePath('/admin/cursos'); revalidatePath('/cursos');
}

export async function setCourseStatus(formData: FormData) {
  const supabase = await adminClient();
  const id = String(formData.get('id') || '');
  const status = String(formData.get('status') || 'draft');
  if (!['draft','published','archived'].includes(status)) throw new Error('Status inválido.');
  const { error } = await supabase.from('courses').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
  if (error) throw new Error(error.message);
  revalidatePath('/admin/cursos'); revalidatePath('/dashboard'); revalidatePath('/cursos');
}

export async function createLesson(formData: FormData) {
  const supabase = await adminClient();
  const courseId = String(formData.get('course_id') || '');
  const title = String(formData.get('title') || '').trim();
  if (!courseId || !title) throw new Error('Selecione o curso e informe o título da aula.');
  const { error } = await supabase.from('lessons').insert({ course_id: courseId, title, description: String(formData.get('description') || ''), body: String(formData.get('body') || ''), external_video_url: String(formData.get('video_url') || '') || null, is_preview: formData.get('is_preview') === 'on', status: 'published', content_type: 'text' });
  if (error) throw new Error(error.message);
  revalidatePath('/admin/cursos'); revalidatePath('/dashboard');
}

export async function createMaterial(formData: FormData) {
  const supabase = await adminClient();
  const lessonId = String(formData.get('lesson_id') || '');
  const title = String(formData.get('title') || '').trim();
  const url = String(formData.get('url') || '').trim();
  if (!lessonId || !title || !url || !/^https:\/\//i.test(url)) throw new Error('Informe aula, título e link HTTPS válido.');
  const { error } = await supabase.from('materials').insert({ lesson_id: lessonId, title, external_url: url });
  if (error) throw new Error(error.message);
  revalidatePath('/admin/cursos');
}


export async function uploadMaterial(formData: FormData) {
  const supabase = await adminClient();
  const lessonId = String(formData.get('lesson_id') || '');
  const title = String(formData.get('title') || '').trim();
  const file = formData.get('file');
  if (!lessonId || !title || !(file instanceof File) || file.size === 0) throw new Error('Selecione uma aula, informe o título e escolha um arquivo.');
  if (file.size > 25 * 1024 * 1024) throw new Error('O arquivo deve ter no máximo 25 MB.');
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '-');
  const path = `materiais/${lessonId}/${randomUUID()}-${safeName}`;
  const { error: uploadError } = await supabase.storage.from('kit-materiais').upload(path, file, { contentType: file.type || 'application/octet-stream', upsert: false });
  if (uploadError) throw new Error(uploadError.message);
  const { error } = await supabase.from('materials').insert({ lesson_id: lessonId, title, storage_path: path });
  if (error) { await supabase.storage.from('kit-materiais').remove([path]); throw new Error(error.message); }
  revalidatePath('/admin/cursos');
}

export async function grantCourse(formData: FormData) {
  const supabase = await adminClient();
  const userId = String(formData.get('user_id') || '').trim();
  const courseId = String(formData.get('course_id') || '').trim();
  if (!userId || !courseId) throw new Error('Informe o ID do aluno e selecione um curso.');
  const { error } = await supabase.from('access_grants').insert({ user_id: userId, course_id: courseId, source: 'manual_admin', status: 'active' });
  if (error) throw new Error(error.message);
  revalidatePath('/admin'); revalidatePath('/dashboard');
}
