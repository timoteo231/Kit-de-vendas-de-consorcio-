import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { grantCourse } from './actions';

export default async function AdminPage() {
  const supabase = await createClient();
  const { data: claimsData } = await supabase.auth.getClaims();
  const userId = claimsData?.claims?.sub;
  if (!userId) redirect('/login');
  const { data: profile } = await supabase.from('profiles').select('full_name,role').eq('id',userId).maybeSingle();
  if (profile?.role !== 'admin') redirect('/dashboard');
  const [courses, lessons, grants, profiles, courseList, users, orders] = await Promise.all([
    supabase.from('courses').select('id',{count:'exact',head:true}), supabase.from('lessons').select('id',{count:'exact',head:true}),
    supabase.from('access_grants').select('id',{count:'exact',head:true}), supabase.from('profiles').select('id',{count:'exact',head:true}),
    supabase.from('courses').select('id,title,status').order('created_at',{ascending:false}),
    supabase.from('profiles').select('id,full_name,role').order('created_at',{ascending:false}).limit(30),
    supabase.from('orders').select('id,user_id,status,amount_cents,currency,created_at,metadata').eq('provider','mercadopago').order('created_at',{ascending:false}).limit(20),
  ]);
  return <main className="portal-shell"><header className="portal-top"><Link href="/" className="brand">KIT DO <span className="brand-mark">VENDEDOR</span></Link><form action="/auth/signout" method="post"><button className="btn ghost">Sair</button></form></header><section className="portal-content"><span className="eyebrow gold">Painel administrativo</span><h1>Olá, {profile.full_name || 'Administrador'}.</h1><p className="muted">Gerencie cursos, aulas, materiais e liberações.</p><div className="metrics admin-metrics"><div className="metric"><b>{courses.count ?? 0}</b><span>cursos</span></div><div className="metric"><b>{lessons.count ?? 0}</b><span>aulas</span></div><div className="metric"><b>{profiles.count ?? 0}</b><span>contas</span></div><div className="metric"><b>{grants.count ?? 0}</b><span>liberações</span></div></div>
  <div className="card" style={{marginBottom:20}}><h2>Conteúdo</h2><p>Cadastre e publique os produtos educacionais.</p><Link className="btn" href="/admin/cursos">Gerenciar cursos e aulas</Link></div>
  <div className="card" style={{marginBottom:20}}><h2>Liberar acesso para aluno</h2><p className="muted">Use o UUID da conta do aluno, disponível na lista abaixo.</p><form action={grantCourse} className="auth-form"><label>Aluno (UUID)</label><input name="user_id" placeholder="ID da conta" required/><label>Curso</label><select name="course_id" required defaultValue=""><option value="" disabled>Selecione</option>{(courseList.data??[]).map(c=><option key={c.id} value={c.id}>{c.title}</option>)}</select><button className="btn">Conceder acesso</button></form></div>
  <div className="card" style={{marginBottom:20}}><h2>Pedidos Mercado Pago</h2><p className="muted">Últimos 20 pedidos. O acesso só é liberado após confirmação do webhook.</p><div style={{overflowX:'auto'}}><table style={{width:'100%',textAlign:'left',borderCollapse:'collapse'}}><thead><tr><th>Curso</th><th>Valor</th><th>Status</th><th>Data</th></tr></thead><tbody>{(orders.data??[]).map(o=><tr key={o.id}><td>{o.metadata?.course_title || 'Curso'}</td><td>{new Intl.NumberFormat('pt-BR',{style:'currency',currency:o.currency||'BRL'}).format((o.amount_cents||0)/100)}</td><td>{o.status}</td><td>{new Date(o.created_at).toLocaleString('pt-BR')}</td></tr>)}</tbody></table></div></div>
  <div className="card"><h2>Contas cadastradas</h2><div style={{overflowX:'auto'}}><table style={{width:'100%',textAlign:'left',borderCollapse:'collapse'}}><thead><tr><th>Nome</th><th>Perfil</th><th>UUID (para liberar curso)</th></tr></thead><tbody>{(users.data??[]).map(u=><tr key={u.id}><td>{u.full_name||'Sem nome'}</td><td>{u.role}</td><td style={{fontSize:12,wordBreak:'break-all'}}>{u.id}</td></tr>)}</tbody></table></div></div>
  </section></main>;
}
