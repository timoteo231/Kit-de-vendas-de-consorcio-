'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function LoginPage() {
  const router = useRouter();
  const nextPath = typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('next') : null;
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const supabase = createClient();
      const { error: authError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (authError) throw authError;
      const { data: { user } } = await supabase.auth.getUser();
      const { data: profile } = await supabase.from('profiles').select('role').eq('id', user?.id ?? '').maybeSingle();
      const safeNext = nextPath && nextPath.startsWith('/') && !nextPath.startsWith('//') ? nextPath : null;
      router.replace(profile?.role === 'admin' ? '/admin' : (safeNext || '/dashboard'));
      router.refresh();
    } catch (err) { setError(err instanceof Error ? err.message : 'Não foi possível entrar.'); }
    finally { setBusy(false); }
  }
  return <main className="auth-shell"><section className="auth-card"><Link href="/" className="brand">KIT DO <span className="brand-mark">VENDEDOR</span></Link><span className="eyebrow">Área exclusiva</span><h1>Bem-vindo de volta.</h1><p className="muted">Entre com o e-mail e a senha cadastrados na plataforma.</p><form onSubmit={submit} className="auth-form"><label htmlFor="email">E-mail</label><input id="email" type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} /><label htmlFor="password">Senha</label><input id="password" type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)} />{error && <p className="form-error" role="alert">{error}</p>}<button className="btn" disabled={busy}>{busy ? 'Entrando…' : 'Entrar na plataforma'}</button></form><Link href="/cadastro" className="muted back-link">Ainda não tem conta? Cadastre-se</Link><Link href="/" className="muted back-link">Voltar ao início</Link></section></main>;
}
