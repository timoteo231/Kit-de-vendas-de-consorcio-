import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Kit do Vendedor de Consórcio",
    short_name: "Kit Vendedor",
    description: "Academia e ferramentas para vendedores de consórcio.",
    start_url: "/",
    display: "standalone",
    background_color: "#F5F6F3",
    theme_color: "#103D35",
    icons: [],
  };
}
