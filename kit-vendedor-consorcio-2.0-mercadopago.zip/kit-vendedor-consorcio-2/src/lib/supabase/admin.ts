import 'server-only';
import { createClient } from '@supabase/supabase-js';

/** Server-only client. Never import this module from a Client Component. */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const secret = process.env.SUPABASE_SECRET_KEY;
  if (!url || !secret) throw new Error('Configure NEXT_PUBLIC_SUPABASE_URL e SUPABASE_SECRET_KEY no servidor.');
  return createClient(url, secret, {
    auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false },
  });
}
