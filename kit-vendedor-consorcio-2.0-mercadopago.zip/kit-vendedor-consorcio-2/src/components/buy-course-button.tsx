'use client';
import { useState } from 'react';

export function BuyCourseButton({ courseId, label = 'Comprar com Mercado Pago' }: { courseId: string; label?: string }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  async function startCheckout() {
    setLoading(true); setError('');
    try {
      const response = await fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ courseId }) });
      const result = await response.json();
      if (response.status === 401) { window.location.href = '/login?next=%2Fcursos'; return; }
      if (result.redirect) { window.location.href = result.redirect; return; }
      if (!response.ok) throw new Error(result.error || 'Não foi possível iniciar o pagamento.');
      if (!result.checkoutUrl) throw new Error('O Mercado Pago não retornou o endereço de pagamento.');
      window.location.assign(result.checkoutUrl);
    } catch (err) { setError(err instanceof Error ? err.message : 'Erro inesperado.'); setLoading(false); }
  }
  return <div style={{display:'grid',gap:8}}><button className="btn" type="button" onClick={startCheckout} disabled={loading}>{loading ? 'Preparando checkout…' : label}</button>{error && <p className="form-error" role="alert">{error}</p>}</div>;
}
