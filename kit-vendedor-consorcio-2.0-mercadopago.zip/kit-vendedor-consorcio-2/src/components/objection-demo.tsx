"use client";

import { useState } from "react";

const responses: Record<string, { objection: string; answer: string }> = {
  "Demora demais": {
    objection: "Consórcio demora demais.",
    answer:
      "Entendo sua preocupação com o prazo. A contemplação acontece por sorteio ou lance, sem data garantida. Posso explicar como funcionam essas possibilidades e mostrar as regras do grupo?",
  },
  "Prefiro financiar": {
    objection: "Prefiro financiar.",
    answer:
      "São modalidades diferentes. No consórcio não há juros de financiamento, mas existem taxa de administração e outros encargos previstos em contrato. Podemos comparar o custo total, o prazo e sua necessidade de receber o bem?",
  },
  "Tenho medo": {
    objection: "Tenho medo de não ser contemplado.",
    answer:
      "É importante avaliar isso antes de entrar. A contemplação depende das regras do grupo e pode ocorrer por sorteio ou lance, sem garantia de data. Posso mostrar os pontos do contrato que você deve analisar?",
  },
  "Vou pensar": {
    objection: "Vou pensar.",
    answer:
      "Claro. Para ajudar na sua decisão, qual ponto você gostaria de entender melhor: valor da parcela, prazo, reajustes ou regras de contemplação?",
  },
};

export function ObjectionDemo() {
  const [selected, setSelected] = useState("");
  const [copied, setCopied] = useState(false);
  const current = selected ? responses[selected] : null;

  async function copyAnswer() {
    if (!current) return;
    try {
      await navigator.clipboard.writeText(current.answer);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
      window.prompt("Copie sua resposta:", current.answer);
    }
  }

  return (
    <div className="demo">
      <strong>Experimente uma conversa de vendas</strong>
      <p className="muted">Escolha uma objeção para ver uma sugestão de resposta responsável.</p>
      <div className="chips" role="group" aria-label="Objeções do cliente">
        {Object.keys(responses).map((label) => (
          <button
            className="chip"
            key={label}
            type="button"
            aria-pressed={selected === label}
            onClick={() => { setSelected(label); setCopied(false); }}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="thread" aria-live="polite">
        {current ? (
          <>
            <div className="msg in">{current.objection}</div>
            <div className="msg out">{current.answer}</div>
          </>
        ) : (
          <p className="muted">A resposta aparecerá aqui.</p>
        )}
      </div>
      {current && (
        <button className="copy" type="button" onClick={copyAnswer}>
          {copied ? "Resposta copiada" : "Copiar resposta"}
        </button>
      )}
    </div>
  );
}
